report problems or errors and get some kind of support form @Willi359 on the LMNC forum:
https://lookmumnocomputer.discourse.group

KNOWN PROBLEMS:
- if you order the front pannels from JLC there are problems with edge cuts not showing in the preview. I usualy drop them a note to doublecheck. it works!
- the functional back PCB has internal sub pannels (battery connector & bridges), they add an extra charge for that :(
- if you build the battery connector you have to wrap some wire around the conatact areas an connect it to the footprints (+ & G). don't worry about the standoffs (small t-shaped sub builds), they are not needed.

have FUN and don't blame me if you fry your PO ;)